"""
HTTPie: modern, user-friendly command-line HTTP client for the API era.

"""

__version__ = '3.2.1'
__date__ = '2022-05-06'
__author__ = 'Jakub Roztocil'
__licence__ = 'BSD'
